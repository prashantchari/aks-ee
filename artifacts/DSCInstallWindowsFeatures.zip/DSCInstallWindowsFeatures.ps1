Configuration InstallWindowsFeatures {

    Import-DscResource -ModuleName PsDesiredStateConfiguration

    Node "localhost" {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ActionAfterReboot  = 'ContinueConfiguration'
        }

        WindowsOptionalFeature Hyper-V {
            Name   = "Microsoft-Hyper-V"
            Ensure = "Enable"
        }

        WindowsOptionalFeature Hyper-V-PowerShell {
            Name   = "Microsoft-Hyper-V-PowerShell"
            Ensure = "Enable"
        }

    }
    
}