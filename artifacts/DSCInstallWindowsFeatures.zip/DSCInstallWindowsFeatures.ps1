Configuration InstallWindowsFeatures {

    Import-DscResource -ModuleName PsDesiredStateConfiguration

    Node "localhost" {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ActionAfterReboot  = 'ContinueConfiguration'
        }

        WindowsOptionalFeature Hyper-V {
            Name   = "Microsoft-Hyper-V-All"
            Ensure = "Enable"
        }

    }

}