Configuration InstallWindowsFeatures {

    Import-DscResource -ModuleName PsDesiredStateConfiguration

    Node "localhost" {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ActionAfterReboot  = 'ContinueConfiguration'
        }

        WindowsOptionalFeature Microsoft-Hyper-V {
            Name   = "Microsoft-Hyper-V"
            Ensure = "Present"
        }

    }

}